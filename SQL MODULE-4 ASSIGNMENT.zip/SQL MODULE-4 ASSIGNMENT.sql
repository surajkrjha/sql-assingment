CREATE DATABASE ASSIGNMENT4;
USE ASSIGNMENT4;

##MODULE4

1. Use the inbuilt functions and find the minimum, maximum and average amount from the orders
table
2. Create a user-defined function, which will multiply the given number with 10
3. Use the case statement to check if 100 is less than 200, greater than 200 or equal to 200 and
print the corresponding value


CREATE TABLE ORDERS(
ORDER_ID INT,
ORDER_DATE DATE,
AMMOUNT INT,
CUSTOMER_ID INT);
SELECT * FROM ORDERS;
INSERT INTO ORDERS VALUES
(1,'2022-1-10','200',30),
(2,'2022-2-11','300',40),
(3,'2022-3-12','400',50),
(4,'2022-4-13','500',20),
(5,'2022-5-14','600',10);


 1. SELECT MAX(AMMOUNT) FROM ORDERS;
    SELECT MIN(AMMOUNT) FROM ORDERS;
    SELECT AVG(AMMOUNT) FROM ORDERS;


2. CREATE FUNCTION MULTIPLY(@NUMBER INT)
   RETURNS INT
   AS BEGIN
   RETURN @NUMBER * 10
     END

  .Create Function dbo.multiplyby10(@Num int) RETURNS INT AS
BEGIN
	DECLARE @result int
	SET @result = @Num * 10
	return @result
END

 3. DECLARE @num1 int
DECLARE @num2 int
SET @num1 = 100
SET @num2 = 200
SELECT
CASE
	WHEN @num1 > @num2 THEN CONCAT (@num1, ' is greater than ', @num2)
	WHEN @num1 = @num2 THEN CONCAT (@num1, ' is equal to ', @num2)
	WHEN @num1 < @num2 THEN CONCAT (@num1, ' is less than ', @num2)
END AS COMPAREVALUES

