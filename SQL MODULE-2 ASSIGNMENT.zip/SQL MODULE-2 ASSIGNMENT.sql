CREATE DATABASE ASSIGNMENT2;
USE ASSIGNMENT2;

##MODULE 2.....##

1. Create a customer table which comprises of these columns � �customer_id�, �first_name�,
  �last_name�, �email�, �address�, �city�,�state�,�zip�
2. Insert 5 new records into the table
3. Select only the �first_name� & �last_name� columns from the customer table
4. Select those records where �first_name� starts with �G� and city is �San Jose�

CREATE TABLE CUSTOMERS(
CUSTOMERS_ID INT,
FIRST_NAME VARCHAR(20),
LAST_NAME VARCHAR (20),
EMAIL VARCHAR(20),
ADDRESS VARCHAR(20),
CITY VARCHAR(20),
STATE VARCHAR(10),
ZIP VARCHAR(10)
);
SELECT*FROM CUSTOMERS;
INSERT INTO CUSTOMERS VALUES
	  (10,'JEMMI','SWQ','JEM@GMAIL.COM','2ND FLOOR','LEH','MYSORE','33222'),

	  (20,'JEMMI','AVANTHIKA','JEMMI@GMAIL.COM','2ND FLOOR','LEH','KASHMIR','22222'),

         (30,'JESSICA','VANYA','VANYA@GMAIL.COM','3RD FLOOR','ALLEPPY','KERALA','33333'),

	  (40,'JERUSHA','JERU','JERU@GMAIL.COM','4TH FLOOR','OOTY','BANGLORE','44444'),

	  (50,'GRACE','ZIPPORA','GRACE@GMAIL.COM','5TH FLOOR','SAN JOSE','LA','55555');
	 
	   1. SELECT FIRST_NAME,LAST_NAME FROM CUSTOMERS;

	 2.  Select * from customerS where first_name like 'G%' and city='san jose'







