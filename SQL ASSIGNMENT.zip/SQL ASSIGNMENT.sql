CREATE DATABASE SQLASSIGNMENT;
USE SQLASSIGNMENT;

##MODULE5

CREATE TABLE Employee_table(
Employee_id int,
First_name varchar(10),
Last_name varchar(10),
Salary int,
Joining_date datetime,
Department varchar(10)
);
insert into Employee_table values
(1,'Anika','Arors',100000,2020-02-14,'HR'),
(2,'Veena','Verma',80000,2011-06-15,'Admin'),
(3,'Vishal','Singhal',300000,2020-02-16,'HR'),
(4,'Shushanth','Singh',500000,2020-02-17,'Admin'),
(5,'Bhupal','Bhati',500000,2011-06-18,'Admin'),
(6,'Dheeraj','Diwan',200000,2011-06-19,'Account'),
(7,'Karan','Kumar',75000,2020-01-14,'Account'),
(8,'Chandrika','Chuhan',90000,2011-04-15,'Admin')


CREATE TABLE Bonus_table(
Employee_ref_id INT,
Bonus_Ammount int,
Bonus_date datetime,
);

insert into Bonus_table values
(1,5000,2020-02-16),
(2,3000,2011-06-16),
(3,4000,2020-02-16),
(1,4500,2020-02-16),
(2,3500,2011-06-16)

create table Employee_TitleTable(
Employee_ref_id int,
Employee_title varchar(20),
Affective_date datetime
);

insert into Employee_TitleTable values
(1,'Manager',2016-02-20),
(2,'Executive',2016-02-20),
(8,'Executive',2016-02-20),
(5,'Manager',2016-02-20),
(4,'Asst.manager',2016-02-20),
(7,'Executive',2016-02-20),
(6,'Lead',2016-02-20),
(3,'Lead',2016-02-20)
   


1 Display the �FIRST_NAME� from Employee_table table using the alias name
 as Employee_name.
     Select First_name as Employee_name from Employee_table
2 Display �LAST_NAME� from Employee_table table in upper case.
     select upper(Last_name) from Employee_table
3 Display unique values of DEPARTMENT from EMPLOYEE table.
     Select distinct department from Employee_table
4 Display the first three characters of LAST_NAME from EMPLOYEE table.
     Select substring( First_name,1,3) from Employee_table
5 Display the unique values of DEPARTMENT from EMPLOYEE table and
prints its length.
     Select   department,len( Department) len from Employee_table
      group by department
6 Display the FIRST_NAME and LAST_NAME from EMPLOYEE table into a
  single column AS FULL_NAME a space char should separate them.

     Select First_name + ' ' + last_name as Full_name from Employee_table

7 DISPLAY all EMPLOYEE details from the employee table
  order by FIRST_NAME Ascending.
     Select * from Employee_table order by first_name asc
8. Display all EMPLOYEE details order by FIRST_NAME Ascending and
   DEPARTMENT Descending.
    Select * from Employee_table order by first_name asc ,Department desc
9 Display details for EMPLOYEE with the first name as �VEENA� and
   �KARAN� from EMPLOYEE table.
    Select * from Employee_table where first_name ='Veena' or first_name='Karan'
10 Display details of EMPLOYEE with DEPARTMENT name as �Admin�.

    Select * from Employee_table where Department='Admin'

11 DISPLAY details of the EMPLOYEES whose FIRST_NAME contains �V�.

    Select * from Employee_table where first_name  like '%V%'

12 DISPLAY details of the EMPLOYEES whose SALARY lies between
  100000 and 500000.

  Select * from Employee_table where salary between 100000 and 500000

13 Display details of the employees who have joined in Feb-2020.

   Select * from  Employee_table  where datepart(month,Joining_date)=2 and datepart(year,Joining_date)=2020

14 Display employee names with salaries >= 50000 and <= 100000.

15 DISPLAY details of the EMPLOYEES who are also Managers.

     Select * from Employee_table  e inner join Employee_TitleTable et on e.Employee_id=et.employee_id and et.Employee_title='Manager'

16 DISPLAY duplicate records having matching data in some fields of a table.
     Select * from Employee_table where salary in (Select salary from Employee_table  group by salary having count(*)>1)
17 Display only odd rows from a table.

   Select * from Employee_table where Employee_id in(
   Select Employee_id from Employee_table group by Employee_id having Employee_id%2<>0)
18 Clone a new table from EMPLOYEE table.
    Select * into EMPLOYEE_clone from Employee_table
19 DISPLAY the TOP 2 highest salary from a table.
    Select top 2 with ties salary  from Employee_table order by salary desc
20. DISPLAY the list of employees with the same salary.
   Select e.* from Employee e  inner join Employee e1 on e.Employeeid<>e1.Employeeid and e.salary=e1.salary
21 Display the second highest salary from a table.
   with cte as (Select *,row_number() over ( order by salary desc ) row_id from Employee)
   Select top 1* from cte where row_id>1 and salary<(Select salary from cte where row_id=1)
22 Display the first 50% records from a table.
Select top 50 percent * from Employee
23 Display the departments that have less than 4 people in it.
Select Department from Employee_table group by Department having count(*)<4
24 Display all departments along with the number of people in there.
Select count(*) as employeecount ,dept from employee group by dept

25 Display the name of employees having the highest salary in each
department.
with cte as (Select * ,row_number() over (partition by dept order by salary desc) row_id from employee)
Select * from cte where row_id=2
26 Display the names of employees who earn the highest salary.
with cte as (Select * ,dense_rank() over (order by salary desc) row_id from employee)
Select * from cte where row_id=1
27 Display the average salaries for each department
Select avg(salary),dept from employee group by dept
28 display the name of the employee who has got maximum bonus
Select * from Employee where Employeeid in(Select Employeeid from employeebonus where  bonusamount in(
Select max(bonusamount) from employeebonus))
29 Display the first name and title of all the employees

Select first_name ,Employeetitle from Employee e inner join employeetitle et on e.Employeeid=et.employeeid


